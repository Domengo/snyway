/*****************************************************************************
*             Copyright (c) 1995 - 20xx by GAO Research Inc.                 *
*                          All rights reserved.                              *
*                                                                            *
*  This program is a confidential and an unpublished work of GAO Research    *
*  Inc. that is protected under international and Canadian copyright laws.   *
*  This program is a trade secret and constitutes valuable property of GAO   *
*  Research Inc. All use, reproduction and/or disclosure in whole or in      *
*  part of this program is strictly prohibited unless expressly authorized   *
*  in writing by GAO Research Inc.                                           *
*****************************************************************************/

/**********************************************************************/
/*                   T Y P E S . H                                    */
/**------------------------------------------------------------------**/
/*  Task         : Define frequently used constants and macros        */
/**********************************************************************/
#ifndef _TYPES_H
#define _TYPES_H

#include "commdef.h"

#ifndef _FP
#define _FP near
#endif

typedef void _FP   *LPVOID;

#define LOBYTE(w)        ((UBYTE)((w) & 0xFF))
#define HIBYTE(w)        ((UBYTE)(((w) >> 8) & 0xFF))
#define MAKEWORD(h, l)   (((UDWORD)(h) << 8) | (UDWORD)(l))

#ifndef _interrupt
#define _interrupt interrupt
#endif

#endif
