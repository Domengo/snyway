#define USE_GAO_DTE             (1)
#define NUMBER_OF_CHANNELS      (1)
